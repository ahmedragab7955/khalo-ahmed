package com.khaloahmed.launcher;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.*;
import android.view.*;
import org.json.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {

    private WebView webView;

    private static final Map<String, String[]> PLATFORM_CONFIG = new LinkedHashMap<String, String[]>() {{
        put("PS1", new String[]{"/storage/0CF6-106E/ps1", "com.epsxe.ePSXe",         ".bin,.iso,.img,.pbp,.cue"});
        put("PSP", new String[]{"/storage/0CF6-106E/psp", "org.ppsspp.ppsspp",        ".iso,.cso,.pbp"});
        put("GBC", new String[]{"/storage/0CF6-106E/gbc", "com.fastemulator.gbcfree", ".gbc,.gb,.zip"});
    }};

    private static final Set<String> IMAGE_EXTS = new HashSet<>(Arrays.asList(".png",".jpg",".jpeg",".webp"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        webView = new WebView(this);
        setContentView(webView);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/launcher/index.html");
    }

    class AndroidBridge {
        @JavascriptInterface
        public String getGamesList() {
            JSONArray games = new JSONArray();
            try {
                for (Map.Entry<String, String[]> entry : PLATFORM_CONFIG.entrySet()) {
                    String platform = entry.getKey();
                    String folderPath = entry.getValue()[0];
                    String extsStr = entry.getValue()[2];
                    Set<String> exts = new HashSet<>(Arrays.asList(extsStr.split(",")));
                    File folder = new File(folderPath);
                    if (!folder.exists() || !folder.isDirectory()) continue;
                    File[] allFiles = folder.listFiles();
                    if (allFiles == null) continue;
                    Set<String> imageBaseNames = new HashSet<>();
                    Map<String, String> imagePathMap = new HashMap<>();
                    for (File f : allFiles) {
                        String n = f.getName().toLowerCase();
                        for (String ie : IMAGE_EXTS) {
                            if (n.endsWith(ie)) {
                                String base = n.substring(0, n.lastIndexOf('.'));
                                imageBaseNames.add(base);
                                imagePathMap.put(base, f.getAbsolutePath());
                            }
                        }
                    }
                    for (File f : allFiles) {
                        if (!f.isFile()) continue;
                        String name = f.getName();
                        String nameLower = name.toLowerCase();
                        boolean isRom = false;
                        for (String ext : exts) { if (nameLower.endsWith(ext.trim())) { isRom = true; break; } }
                        if (!isRom) continue;
                        String baseName = name.contains(".") ? name.substring(0, name.lastIndexOf('.')) : name;
                        String displayName = baseName.replaceAll("[_\\-]", " ").trim();
                        String artPath = imagePathMap.containsKey(baseName.toLowerCase()) ? imagePathMap.get(baseName.toLowerCase()) : "";
                        JSONObject game = new JSONObject();
                        game.put("name", displayName);
                        game.put("platform", platform);
                        game.put("file", name);
                        game.put("path", f.getAbsolutePath());
                        game.put("art", artPath);
                        games.put(game);
                    }
                }
            } catch (Exception e) { e.printStackTrace(); }
            return games.toString();
        }

        @JavascriptInterface
        public void launchGame(String packageName, String romPath) {
            try {
                Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
                if (intent == null) return;
                intent.setData(Uri.fromFile(new File(romPath)));
                intent.putExtra("romPath", romPath);
                intent.putExtra("com.epsxe.ePSXe.ROM", romPath);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch (Exception e) { e.printStackTrace(); }
        }
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript(
            "if(document.getElementById('nowPlaying').classList.contains('show')){closeNowPlaying();}", null);
    }
}
